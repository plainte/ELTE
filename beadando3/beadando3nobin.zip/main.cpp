#include "App.h"

int main() {
    return App::Run();
}
